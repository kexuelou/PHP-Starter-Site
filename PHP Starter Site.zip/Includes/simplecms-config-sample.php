<?php
    define('DB_NAME', 'database_name_here');
    define('DB_USER', 'username_here');
    define('DB_PASSWORD', 'password_here');
    define('DB_HOST', 'localhost');

    define('DEFAULT_ADMIN_USERNAME', 'PlaceHolderForAdminUser');
    define('DEFAULT_ADMIN_PASSWORD', 'PlaceHolderForAdminPassword');
?>