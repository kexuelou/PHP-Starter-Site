<?php
    define('DB_NAME', 'cdb_9955390a7f');
    define('DB_USER', 'b76f2bde221659');
    define('DB_PASSWORD', 'e99c6a71');
    define('DB_HOST', 'us-cdbr-azure-east-b.cloudapp.net');

    define('DEFAULT_ADMIN_USERNAME', 'admin');
    define('DEFAULT_ADMIN_PASSWORD', 'iis6!dfu');
?>