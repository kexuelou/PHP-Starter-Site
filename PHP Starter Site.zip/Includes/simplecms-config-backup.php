<?php
    define('DB_NAME', 'cdb_18adc832b9');
    define('DB_USER', 'b7c992f729bc86');
    define('DB_PASSWORD', '64804069');
    define('DB_HOST', 'ap-cdbr-azure-east-b.cloudapp.net');

    define('DEFAULT_ADMIN_USERNAME', 'admin');
    define('DEFAULT_ADMIN_PASSWORD', 'iis6!dfu');
?>