<?php
    mysqli_close($databaseConnection);
?>
